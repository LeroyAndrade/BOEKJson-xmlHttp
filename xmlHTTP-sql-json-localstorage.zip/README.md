# live url: http://30168.hosts2.ma-cloud.nl/bewijzenmap/periode4.4/fro/sass/BOEKJson-xmlHttp/index.html
Probleem #1: het sorteren werkt niet, wel heb ik succesvol getest dat de onchange eventListener werkt.

--> https://github.com/LeroyAndrade/BOEKJson-xmlHttp/blob/0133fc3b29a541eccd453162dbae3448622a2eba/js/sorteerBoeken.js#L2

Issue1: https://github.com/LeroyAndrade/BOEKJson-xmlHttp/issues/1
